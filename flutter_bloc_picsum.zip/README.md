# Flutter BLoC Picsum Demo

A two-screen Flutter app demonstrating:
- **Login screen** with email + strong password validation using **BLoC**.
- **Home screen** that fetches **10 images** from [https://picsum.photos](https://picsum.photos) and displays them in a vertically padded list.
- **BLoC architecture** with `flutter_bloc`, repositories for API calls, and Google Fonts (Montserrat).

## Run

```bash
flutter pub get
flutter run
```

## Build APK

```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

## Notes

- Login is mocked; successful validation triggers navigation to Home.
- Images are cached with `cached_network_image` and sized using their aspect ratio.
