import 'dart:convert';

class PicsumPhoto {
  final String id;
  final String author;
  final int width;
  final int height;
  final String url;
  final String downloadUrl;

  const PicsumPhoto({
    required this.id,
    required this.author,
    required this.width,
    required this.height,
    required this.url,
    required this.downloadUrl,
  });

  factory PicsumPhoto.fromMap(Map<String, dynamic> map) {
    return PicsumPhoto(
      id: map['id'],
      author: map['author'],
      width: (map['width'] as num).toInt(),
      height: (map['height'] as num).toInt(),
      url: map['url'],
      downloadUrl: map['download_url'],
    );
  }

  static List<PicsumPhoto> listFromJson(String body) {
    final list = jsonDecode(body) as List<dynamic>;
    return list.map((e) => PicsumPhoto.fromMap(e)).toList();
  }
}
