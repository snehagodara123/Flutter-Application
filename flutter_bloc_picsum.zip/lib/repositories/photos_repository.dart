import 'package:http/http.dart' as http;
import '../models/picsum_photo.dart';

class PhotosRepository {
  final http.Client _client;
  PhotosRepository({http.Client? client}) : _client = client ?? http.Client();

  Future<List<PicsumPhoto>> fetchTen() async {
    final uri = Uri.parse('https://picsum.photos/v2/list?page=1&limit=10');
    final res = await _client.get(uri);
    if (res.statusCode != 200) {
      throw Exception('Failed to fetch photos (${res.statusCode})');
    }
    return PicsumPhoto.listFromJson(res.body);
  }
}
