import 'dart:async';

class AuthRepository {
  // Mocked login: succeed if inputs are non-empty and validated by BLoC
  Future<void> login({required String email, required String password}) async {
    await Future.delayed(const Duration(milliseconds: 750));
    // Optionally add server-side checks here.
    return;
  }
}
