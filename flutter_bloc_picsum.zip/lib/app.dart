import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'repositories/auth_repository.dart';
import 'repositories/photos_repository.dart';
import 'bloc/login/login_bloc.dart';
import 'ui/login_screen.dart';
import 'ui/home_screen.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
      useMaterial3: true,
    );

    return MaterialApp(
      title: 'BLoC Picsum Demo',
      theme: theme,
      routes: {
        '/': (_) => BlocProvider(
              create: (ctx) => LoginBloc(
                authRepository: ctx.read<AuthRepository>(),
              ),
              child: const LoginScreen(),
            ),
        '/home': (_) => HomeScreen(photosRepository: _.read<PhotosRepository>()),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}
