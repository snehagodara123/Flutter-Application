class Validators {
  static final RegExp _emailReg = RegExp(
    r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$',
  );

  // At least 8 chars, at least one upper, one lower, one digit, one symbol
  static final RegExp _passReg = RegExp(
    r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$',
  );

  static String? email(String? value) {
    if (value == null || value.trim().isEmpty) return 'Email is required';
    if (!_emailReg.hasMatch(value.trim())) return 'Enter a valid email';
    return null;
  }

  static String? password(String? value) {
    if (value == null || value.isEmpty) return 'Password is required';
    if (!_passReg.hasMatch(value)) {
      return 'Min 8 chars incl. upper, lower, digit & symbol';
    }
    return null;
  }
}
