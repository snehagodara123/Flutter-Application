import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'app.dart';
import 'repositories/auth_repository.dart';
import 'repositories/photos_repository.dart';

void main() {
  runApp(MultiRepositoryProvider(
    providers: [
      RepositoryProvider(create: (_) => AuthRepository()),
      RepositoryProvider(create: (_) => PhotosRepository()),
    ],
    child: const MyApp(),
  ));
}
