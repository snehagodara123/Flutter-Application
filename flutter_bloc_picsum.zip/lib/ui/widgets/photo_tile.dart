import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/picsum_photo.dart';

class PhotoTile extends StatelessWidget {
  final PicsumPhoto photo;
  const PhotoTile({super.key, required this.photo});

  @override
  Widget build(BuildContext context) {
    final aspect = photo.width == 0 || photo.height == 0
        ? 1.5
        : photo.width / photo.height;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Image with full width and dynamic height based on aspect ratio
        AspectRatio(
          aspectRatio: aspect,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: CachedNetworkImage(
              imageUrl: photo.downloadUrl,
              fit: BoxFit.cover,
              placeholder: (c, _) => const Center(child: CircularProgressIndicator()),
              errorWidget: (c, _, __) => const Center(child: Icon(Icons.broken_image)),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Image #${photo.id} by ${photo.author}',
          style: GoogleFonts.montserrat(fontWeight: FontWeight.w600, fontSize: 16, color: Colors.black87),
        ),
        const SizedBox(height: 4),
        Text(
          'Original size: ${photo.width}×${photo.height} • Source: ${photo.url}',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.montserrat(fontWeight: FontWeight.w400, fontSize: 13, color: Colors.black54),
        ),
      ],
    );
  }
}
