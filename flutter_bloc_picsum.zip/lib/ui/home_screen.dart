import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import '../repositories/photos_repository.dart';
import '../bloc/photos/photos_bloc.dart';
import '../bloc/photos/photos_event.dart';
import '../bloc/photos/photos_state.dart';
import 'widgets/photo_tile.dart';

class HomeScreen extends StatelessWidget {
  final PhotosRepository photosRepository;
  const HomeScreen({super.key, required this.photosRepository});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => PhotosBloc(repo: photosRepository)..add(const PhotosRequested()),
      child: Scaffold(
        appBar: AppBar(
          title: Text('Picsum Photos', style: GoogleFonts.montserrat(fontWeight: FontWeight.w600)),
          actions: [
            IconButton(
              onPressed: () => context.read<PhotosBloc>().add(const PhotosRefreshed()),
              icon: const Icon(Icons.refresh),
              tooltip: 'Refresh',
            )
          ],
        ),
        body: SafeArea(
          child: BlocBuilder<PhotosBloc, PhotosState>(
            builder: (context, state) {
              switch (state.status) {
                case PhotosStatus.loading:
                  return const Center(child: CircularProgressIndicator());
                case PhotosStatus.failure:
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.error_outline, size: 40),
                          const SizedBox(height: 12),
                          Text(state.error ?? 'Something went wrong'),
                          const SizedBox(height: 12),
                          FilledButton(
                            onPressed: () => context.read<PhotosBloc>().add(const PhotosRequested()),
                            child: const Text('Retry'),
                          ),
                        ],
                      ),
                    ),
                  );
                case PhotosStatus.success:
                  return ListView.separated(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemCount: state.items.length,
                    itemBuilder: (context, index) {
                      final p = state.items[index];
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: PhotoTile(photo: p),
                      );
                    },
                  );
                case PhotosStatus.initial:
                default:
                  return const SizedBox.shrink();
              }
            },
          ),
        ),
      ),
    );
  }
}
