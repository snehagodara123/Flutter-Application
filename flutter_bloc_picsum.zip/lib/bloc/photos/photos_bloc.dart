import 'package:flutter_bloc/flutter_bloc.dart';
import '../../repositories/photos_repository.dart';
import 'photos_event.dart';
import 'photos_state.dart';

class PhotosBloc extends Bloc<PhotosEvent, PhotosState> {
  final PhotosRepository repo;
  PhotosBloc({required this.repo}) : super(const PhotosState()) {
    on<PhotosRequested>(_onRequested);
    on<PhotosRefreshed>(_onRequested);
  }

  Future<void> _onRequested(PhotosEvent e, Emitter<PhotosState> emit) async {
    emit(state.copyWith(status: PhotosStatus.loading));
    try {
      final data = await repo.fetchTen();
      emit(state.copyWith(status: PhotosStatus.success, items: data));
    } catch (err) {
      emit(state.copyWith(status: PhotosStatus.failure, error: err.toString()));
    }
  }
}
