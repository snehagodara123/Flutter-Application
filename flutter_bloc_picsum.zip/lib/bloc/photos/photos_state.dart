import 'package:equatable/equatable.dart';
import '../../models/picsum_photo.dart';

enum PhotosStatus { initial, loading, success, failure }

class PhotosState extends Equatable {
  final PhotosStatus status;
  final List<PicsumPhoto> items;
  final String? error;

  const PhotosState({
    this.status = PhotosStatus.initial,
    this.items = const [],
    this.error,
  });

  PhotosState copyWith({
    PhotosStatus? status,
    List<PicsumPhoto>? items,
    String? error,
  }) => PhotosState(status: status ?? this.status, items: items ?? this.items, error: error);

  @override
  List<Object?> get props => [status, items, error];
}
