import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/validation.dart';
import '../../repositories/auth_repository.dart';
import 'login_event.dart';
import 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final AuthRepository authRepository;
  LoginBloc({required this.authRepository}) : super(const LoginState()) {
    on<LoginEmailChanged>(_onEmailChanged);
    on<LoginPasswordChanged>(_onPasswordChanged);
    on<LoginSubmitted>(_onSubmitted);
  }

  void _onEmailChanged(LoginEmailChanged e, Emitter<LoginState> emit) {
    final emailError = Validators.email(e.email);
    emit(state.copyWith(
      email: e.email,
      emailError: emailError,
      passwordError: state.passwordError,
      status: emailError == null && state.passwordError == null ? LoginStatus.valid : LoginStatus.invalid,
    ));
  }

  void _onPasswordChanged(LoginPasswordChanged e, Emitter<LoginState> emit) {
    final passError = Validators.password(e.password);
    emit(state.copyWith(
      password: e.password,
      passwordError: passError,
      emailError: state.emailError,
      status: passError == null && state.emailError == null ? LoginStatus.valid : LoginStatus.invalid,
    ));
  }

  Future<void> _onSubmitted(LoginSubmitted e, Emitter<LoginState> emit) async {
    final emailErr = Validators.email(state.email);
    final passErr = Validators.password(state.password);
    if (emailErr != null || passErr != null) {
      emit(state.copyWith(emailError: emailErr, passwordError: passErr, status: LoginStatus.invalid));
      return;
    }
    emit(state.copyWith(status: LoginStatus.submitting));
    try {
      await authRepository.login(email: state.email, password: state.password);
      emit(state.copyWith(status: LoginStatus.success));
    } catch (err) {
      emit(state.copyWith(status: LoginStatus.failure, errorMessage: err.toString()));
    }
  }
}
